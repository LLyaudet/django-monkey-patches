# django-monkey-patches
A collection of monkey patches to improve Django framework
